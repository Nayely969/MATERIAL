# color
paleta de colores
